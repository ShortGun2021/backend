const auth = require('./auth');
const createNFT = require('./createNFT');


module.exports = app => {
    app.use('/auth', auth);
    app.use('/createNFT', createNFT);
    
};
